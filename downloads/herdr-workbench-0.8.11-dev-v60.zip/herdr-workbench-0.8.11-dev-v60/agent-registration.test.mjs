import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {randomUUID} from 'node:crypto';
import {context,roster,saveRoster,executeRequest,captureReply} from './team-runtime.mjs';
import {enqueueDirect,drainDirect,directTerminal,reconcileWorkerMembers,pendingRegistrations,retryDirect} from './direct.mjs';
const read=p=>JSON.parse(fs.readFileSync(p));
function fixture(t,provider='codex'){
 const root=fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(),'herdr-register52-'))),home=path.join(root,'host'),config={headless:true,stateRoot:path.join(root,'state'),appHome:home};t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 const c=context(root,null,null,'chat',config);fs.mkdirSync(c.teamDir,{recursive:true});fs.mkdirSync(path.join(home,'web'),{recursive:true});fs.writeFileSync(path.join(home,'service.json'),JSON.stringify(config));fs.writeFileSync(path.join(home,'web/projects.json'),JSON.stringify([{folder:root,chats:[{id:'chat'}]}]));fs.writeFileSync(path.join(c.teamDir,'control.json'),JSON.stringify({terminal:'towner',role:'claude',phase:'active'}));
 const calls=[],terminals=new Map();let failGet=false,lostResponse=false,firstSent=true;const app=provider==='claude'?'claude-code':provider==='minimax'?'mcode':provider;
 const run=(_cmd,args)=>{calls.push(args);if(args[0]==='run'){
  const labels={};for(let i=0;i<args.length;i++)if(args[i]==='--label'){const at=args[++i].indexOf('=');labels[args[i].slice(0,at)]=args[i].slice(at+1);}
  const terminal={address:'tworker',pid:1234,cwd:args[args.indexOf('--cwd')+1],parent:'towner',state:'live',turn:1,status:{app,state:firstSent?'working':'blocked'},labels};terminals.set('tworker',terminal);
  if(lostResponse)throw Error('Core response was lost');return{address:'tworker',first_message:{sent:firstSent}};
 }if(args[0]==='get'){
  if(failGet)throw Error('Core temporarily unavailable');if(args[1]==='towner')return{address:'towner',cwd:c.cwd,state:'live',parent:null,status:{app:'claude-code',state:'done'},labels:{}};const terminal=terminals.get(args[1]);if(!terminal)throw Object.assign(Error('not found'),{stdout:JSON.stringify({error:{kind:'not_found'}})});return structuredClone(terminal);
 }if(args[0]==='ls'){
  const filters=args.flatMap((x,i)=>x==='--label'?[args[i+1]]:[]);return{terminals:[...terminals.values()].filter(t=>filters.every(f=>{const at=f.indexOf('=');return t.labels[f.slice(0,at)]===f.slice(at+1);})).map(t=>({address:t.address}))};
 }if(args[0]==='send'){const t=terminals.get(args[1]);assert(t);t.turn++;t.status.state='working';return{ok:true};}if(args[0]==='read')return{text:'GPT-6.1-Sol medium · Context 20%\n算術結果'};assert.fail('Unexpected Core action '+args[0]);};c.run=run;
 const template={claude:'herdr-claude-task',codex:'herdr-codex-implement',minimax:'herdr-minimax-cn',antigravity:'herdr-antigravity-task'}[provider];
 const req={id:randomUUID(),sender:'towner',action:'run',args:{template,name:'registration-test',displayName:'資料核對員',brief:'依目前任務唯讀核對資料',profile:{responsibilities:'獨立計算與比對小型資料，回報真實差異',expertise:'熟悉算術、資料格式與雜湊驗證方法',deliverables:'依本次要求提供可核對數值與具體成果',verification:'逐項核對輸入與輸出，保留真實驗證證據',boundaries:'僅處理本次授權範圍，受阻停止且不擴權'},creationReason:'目前名冊缺少獨立資料核對所需的角色與專業',reviewedAgentIds:[],task:'只計算 10+17，不修改檔案'}};
 return{c,root,home,config,req,provider,calls,terminals,run,setFailGet:v=>failGet=v,setLostResponse:v=>lostResponse=v,setFirstSent:v=>firstSent=v};
}
const event=(provider,text,key)=>provider==='claude'?{hook_event_name:'Stop',session_id:key,last_assistant_message:text}:{type:'agent-turn-complete','turn-id':key,'last-assistant-message':text};
for(const provider of ['claude','codex','minimax','antigravity'])test(`${provider} legacy creation immediately registers one normal chat member, keeps its process, and pairs later direct replies`,t=>{
 const f=fixture(t,provider),made=executeRequest(f.c,f.req);assert(made.registered);assert.equal(made.address,'tworker');assert.equal(roster(f.c).length,1);assert.equal(roster(f.c)[0].name,'資料核對員');assert.match(roster(f.c)[0].brief,/專業技能/);assert.equal(directTerminal(f.c,'tworker').binding.agentId,made.agentId);
 assert.equal(executeRequest(f.c,f.req).agentId,made.agentId);assert.equal(f.calls.filter(a=>a[0]==='run').length,1);
 const message=randomUUID();enqueueDirect(f.c,made.agentId,'Answer 12+13',message);assert.equal(drainDirect(f.c).reason,'waiting_owner_task');f.terminals.get('tworker').status.state='done';
 const role={claude:'Claude',codex:'Codex',minimax:'MiniMax',antigravity:'Antigravity'}[provider];assert(captureReply(event(provider,'10+17=27','owner-turn'),{...f.c,terminal:'tworker'},role).captured);assert.equal(drainDirect(f.c).terminal,'tworker');assert(captureReply(event(provider,'12+13=25','direct-turn'),{...f.c,terminal:'tworker'},role).captured);
 const rows=fs.readFileSync(path.join(f.c.teamDir,'messages.jsonl'),'utf8').trim().split('\n').map(JSON.parse);assert(rows.some(r=>r.kind==='worker-report'&&r.text==='10+17=27'));assert(rows.some(r=>r.replyTo===message&&r.agentId===made.agentId&&r.text==='12+13=25'));assert.equal(f.calls.filter(a=>a[0]==='run').length,1);assert(fs.existsSync(path.join(f.c.teamBase,'registration-backups')));
});
test('existing member names, models, briefs, and pins survive legacy launch without a second roster identity',t=>{
 const f=fixture(t,'claude'),member={id:'planner',name:'我的企劃',provider:'claude',model:'claude-fable-5-2',brief:'保留我的設定',level:'manager'};saveRoster(f.c,[member]);fs.writeFileSync(path.join(f.c.teamBase,'sidebar.json'),JSON.stringify({revision:3,order:['planner'],pinned:['planner']}));f.req.args.agentId='planner';delete f.req.args.template;
 const before=fs.readFileSync(path.join(f.c.teamBase,'roster.json')),pins=fs.readFileSync(path.join(f.c.teamBase,'sidebar.json'));const made=executeRequest(f.c,f.req);assert(made.registered);assert.equal(made.agentId,'planner');assert.equal(executeRequest(f.c,f.req).agentId,'planner');assert(fs.readFileSync(path.join(f.c.teamBase,'roster.json')).equals(before));assert(fs.readFileSync(path.join(f.c.teamBase,'sidebar.json')).equals(pins));
});
test('unknown launch results block duplicate engines and management until real Core identity is recovered',async t=>{
 const f=fixture(t);f.setLostResponse(true);assert.throws(()=>executeRequest(f.c,f.req),/啟動結果待核對/);const agent=roster(f.c)[0];assert.equal(pendingRegistrations(f.c).length,1);enqueueDirect(f.c,agent.id,'Later task',randomUUID());assert.equal(drainDirect(f.c).reason,'registration_pending');
 assert.throws(()=>executeRequest(f.c,{...f.req,id:randomUUID()}),/尚未核對/);assert.equal(f.calls.filter(a=>a[0]==='run').length,1);const {manageAgent,rosterRevision}=await import('./web/agent-management.mjs');await assert.rejects(()=>manageAgent({source:f.c,sourceWorkspace:false,agentId:agent.id,expectedRevision:rosterRevision(f.c),core:a=>f.run('hc',a)}),/啟動結果仍待核對/);
 assert.equal(reconcileWorkerMembers(f.c).registered,1);assert.equal(pendingRegistrations(f.c).length,0);assert.equal(directTerminal(f.c,'tworker').binding.agentId,agent.id);assert.equal(f.calls.filter(a=>a[0]==='run').length,1);
});
test('only an explicit retry and authoritative empty listing clears an unresolved launch; it never retries permission or starts work',t=>{
 const f=fixture(t);f.setLostResponse(true);assert.throws(()=>executeRequest(f.c,f.req));const agent=roster(f.c)[0];f.terminals.clear();const original=f.c.run;f.c.run=()=>{throw Error('Core temporarily unavailable');};assert.throws(()=>retryDirect(f.c,agent.id));assert.equal(pendingRegistrations(f.c).length,1);f.c.run=original;assert.equal(retryDirect(f.c,agent.id).restarted,false);assert.equal(pendingRegistrations(f.c).length,0);assert.equal(f.calls.filter(a=>a[0]==='run').length,1);assert(!f.calls.some(a=>a[0]==='keys'));
});
test('a worker pending folder trust registers without pretending its first task was delivered',t=>{
 const f=fixture(t);f.setFirstSent(false);const made=executeRequest(f.c,f.req);assert(made.registered);assert.equal(made.first_message.sent,false);const binding=directTerminal(f.c,'tworker').binding;assert.equal(binding.ownerAwaitingReply,false);enqueueDirect(f.c,made.agentId,'Wait for user',randomUUID());assert.equal(drainDirect(f.c).reason,'agent_not_ready');assert(!f.calls.some(a=>a[0]==='send'||a[0]==='keys'));
});
test('legacy children automatically join once without replaying tasks, while removed members never resurrect',t=>{
 const f=fixture(t);const t1={address:'told',cwd:f.c.cwd,parent:'towner',state:'live',status:{app:'codex',state:'done'},labels:{'team.owner':'towner','team.chat':'chat'}};f.terminals.set('told',t1);fs.writeFileSync(path.join(f.c.teamDir,'worker-bindings.json'),JSON.stringify({told:{owner:'towner',chat:'chat',name:'舊核對員'}}));assert.equal(reconcileWorkerMembers(f.c).registered,1);const id=roster(f.c)[0].id;assert.equal(reconcileWorkerMembers(f.c).registered,0);assert.equal(roster(f.c).length,1);saveRoster(f.c,[]);assert.equal(reconcileWorkerMembers(f.c).registered,0);assert.equal(roster(f.c).length,0);assert(!f.calls.some(a=>a[0]==='run'||a[0]==='send'));
});
test('new launch limits, foreign callers and mismatched recovered terminals fail before any duplicate launch',t=>{
 const f=fixture(t);saveRoster(f.c,Array.from({length:24},(_,i)=>({id:'member-'+i,name:'成員'+i,provider:'codex',level:'worker'})));assert.throws(()=>executeRequest(f.c,f.req),/24/);assert(!f.calls.some(a=>a[0]==='run'));assert.throws(()=>executeRequest(f.c,{...f.req,sender:'tforeign'}),/active coordinator/);
 saveRoster(f.c,[]);f.setLostResponse(true);assert.throws(()=>executeRequest(f.c,f.req));f.terminals.get('tworker').parent='tforeign';assert.equal(reconcileWorkerMembers(f.c).registered,0);assert.equal(pendingRegistrations(f.c).length,1);assert.equal(f.calls.filter(a=>a[0]==='run').length,1);
});
test('subdirectory workers retain their sandbox cwd and use project-scoped metadata for later direct messages',t=>{
 const f=fixture(t),child=path.join(f.root,'child');fs.mkdirSync(child);f.req.args.cwd='child';const made=executeRequest(f.c,f.req);assert(made.registered);assert.equal(f.terminals.get('tworker').cwd,child);assert.equal(f.terminals.get('tworker').labels['team.project'],f.root);f.terminals.get('tworker').status.state='done';captureReply(event('codex','First task done','owner-turn'),{...f.c,terminal:'tworker'},'Codex');enqueueDirect(f.c,made.agentId,'Next task',randomUUID());assert.equal(drainDirect(f.c).terminal,'tworker');assert(f.calls.findLast(a=>a[0]==='send')[2].includes('專案根目錄：'+f.root));assert.equal(f.calls.filter(a=>a[0]==='run').length,1);
});


test('MiniMax native Stop locates a registered subdirectory worker without broadening its workspace',async t=>{
 const f=fixture(t,'minimax'),child=path.join(f.root,'child');fs.mkdirSync(child);f.req.args.cwd='child';const made=executeRequest(f.c,f.req);f.terminals.get('tworker').status.state='done';
 const {minimaxReply}=await import('./minimax-reply.mjs');const event={hook_event_name:'Stop',session_id:'mini-child-session',turn_id:'first',cwd:child,last_assistant_message:'算術結果'};assert(minimaxReply(event,f.home,f.run).captured);
 assert.equal(read(path.join(f.c.teamDir,'direct-bindings.json')).tworker.ownerAwaitingReply,false);assert.equal(roster(f.c)[0].id,made.agentId);
});

test('Antigravity validates its real subdirectory workspace before reading the final transcript',async t=>{
 const f=fixture(t,'antigravity'),child=path.join(f.root,'child');fs.mkdirSync(child);f.req.args.cwd='child';executeRequest(f.c,f.req);f.terminals.get('tworker').status.state='done';
 const {agyReply}=await import('./agy-reply.mjs'),conversationId=randomUUID(),brain=path.join(f.root,'brain'),logs=path.join(brain,conversationId,'.system_generated/logs');fs.mkdirSync(logs,{recursive:true});const transcriptPath=path.join(logs,'transcript.jsonl');fs.writeFileSync(transcriptPath,[{type:'USER_INPUT',content:'核對'},{source:'MODEL',type:'PLANNER_RESPONSE',status:'DONE',content:'10+17=27'}].map(JSON.stringify).join('\n'));
 const event={fullyIdle:true,terminationReason:'model_stop',conversationId,workspacePaths:[child],transcriptPath,executionNum:1};assert.equal(agyReply({...event,workspacePaths:[f.root]},{...f.c,terminal:'tworker'},brain).reason,'workspace_mismatch');assert(agyReply(event,{...f.c,terminal:'tworker'},brain).captured);
});

for(const provider of ['claude','codex','minimax','antigravity'])test(`${provider} fast first reply survives a lost launch response before background registration`,t=>{
 const f=fixture(t,provider);f.setLostResponse(true);assert.throws(()=>executeRequest(f.c,f.req));f.terminals.get('tworker').status.state='done';
 const role={claude:'Claude',codex:'Codex',minimax:'MiniMax',antigravity:'Antigravity'}[provider];assert(captureReply(event(provider,'First result captured','early-turn'),{...f.c,terminal:'tworker'},role).captured);assert.equal(reconcileWorkerMembers(f.c).registered,1);const agent=roster(f.c)[0];assert.equal(directTerminal(f.c,'tworker').binding.ownerAwaitingReply,false);enqueueDirect(f.c,agent.id,'Next direct task',randomUUID());assert.equal(drainDirect(f.c).terminal,'tworker');assert.equal(f.calls.filter(a=>a[0]==='run').length,1);
});
test('MiniMax early native Stop recovers the true worker and preserves its session through registration',async t=>{
 const f=fixture(t,'minimax');f.setLostResponse(true);assert.throws(()=>executeRequest(f.c,f.req));f.terminals.get('tworker').status.state='done';const {minimaxReply}=await import('./minimax-reply.mjs');
 assert(minimaxReply({hook_event_name:'Stop',session_id:'early-mini',turn_id:'first',cwd:f.root,last_assistant_message:'算術結果'},f.home,f.run).captured);assert.equal(reconcileWorkerMembers(f.c).registered,1);assert.equal(directTerminal(f.c,'tworker').binding.minimaxSessionId,'early-mini');
});


test('manual and delegated members share name validation while unchanged legacy duplicates stay intact',t=>{
 const f=fixture(t);saveRoster(f.c,[{id:'one',name:'核對員',provider:'codex',level:'worker'}]);assert.throws(()=>saveRoster(f.c,[...roster(f.c),{id:'two',name:'核對員',provider:'claude',level:'worker'}]),/同名/);f.req.args.displayName='核對員';f.req.args.reviewedAgentIds=['one'];assert.throws(()=>executeRequest(f.c,f.req),/同名/);assert(!f.calls.some(a=>a[0]==='run'));
 fs.writeFileSync(path.join(f.c.teamBase,'roster.json'),JSON.stringify([{id:'one',name:'舊同名',provider:'codex',level:'worker'},{id:'two',name:'舊同名',provider:'claude',level:'worker'}]));saveRoster(f.c,roster(f.c));assert.deepEqual(roster(f.c).map(a=>a.name),['舊同名','舊同名']);
});


test('adding a worker preserves private custom fields on existing members without exposing them as runtime attributes',t=>{
 const f=fixture(t),file=path.join(f.c.teamBase,'roster.json');fs.writeFileSync(file,JSON.stringify([{id:'existing',name:'既有成員',provider:'claude',model:'claude-fable-5-2',level:'worker',brief:'保留職責',localPreference:{color:'cream'}}]));f.req.args.reviewedAgentIds=['existing'];const made=executeRequest(f.c,f.req);assert(made.registered);const existing=read(file).find(a=>a.id==='existing');assert.deepEqual(existing.localPreference,{color:'cream'});assert.equal(existing.model,'claude-fable-5-2');assert.equal(roster(f.c).find(a=>a.id==='existing').localPreference,undefined);
});


test('legacy launch refuses an existing direct member in another chat instead of creating a duplicate',t=>{
 const f=fixture(t);saveRoster(f.c,[{id:'engineer',name:'工程師',provider:'codex',level:'worker'}]);f.req.args.agentId='engineer';delete f.req.args.template;
 f.terminals.set('totherchat',{address:'totherchat',cwd:f.root,parent:null,state:'live',status:{app:'codex',state:'done'},labels:{'team.direct':'true','team.agent':'engineer','team.chat':'old-chat'}});const old=context(f.root,null,f.run,'old-chat',f.config);fs.mkdirSync(old.teamDir,{recursive:true});fs.writeFileSync(path.join(old.teamDir,'direct-bindings.json'),JSON.stringify({totherchat:{agentId:'engineer',provider:'codex',chat:'old-chat'}}));f.terminals.set('towner',{address:'towner',cwd:f.root,parent:null,state:'live',status:{app:'claude-code',state:'done'},labels:{}});const reused=executeRequest(f.c,f.req);assert(reused.reused);assert(!f.calls.some(a=>a[0]==='run'));assert(fs.readdirSync(path.join(f.c.teamBase,'conversations/old-chat/direct-queue')).some(n=>n.endsWith('.json')));
});


test('new Claude members share the manual Opus default while existing unset preferences are preserved',t=>{
 const f=fixture(t,'claude');fs.writeFileSync(path.join(f.c.teamDir,'model.json'),JSON.stringify({model:'claude-fable-5-2'}));const made=executeRequest(f.c,f.req);assert.equal(roster(f.c).find(a=>a.id===made.agentId).model,'claude-opus-5-5');
 const file=path.join(f.c.teamBase,'roster.json'),old={id:'legacy-member',name:'舊設定',provider:'claude',level:'worker'};const all=read(file);all.push(old);fs.writeFileSync(file,JSON.stringify(all));saveRoster(f.c,roster(f.c));assert.equal(roster(f.c).find(a=>a.id===old.id).model,undefined);
});


test('registration preserves a newly selected engine while the original process is still busy, without launching a duplicate',t=>{
 const f=fixture(t);f.setLostResponse(true);assert.throws(()=>executeRequest(f.c,f.req));const agent=roster(f.c)[0];saveRoster(f.c,roster(f.c).map(a=>({...a,provider:'claude',model:'claude-fable-5-2'})));assert.equal(reconcileWorkerMembers(f.c).registered,1);assert.equal(roster(f.c)[0].provider,'claude');assert.equal(roster(f.c)[0].model,'claude-fable-5-2');assert.equal(directTerminal(f.c,'tworker').binding.provider,'codex');enqueueDirect(f.c,agent.id,'Later work',randomUUID());assert.equal(drainDirect(f.c).reason,'waiting_engine_switch');assert.equal(f.calls.filter(a=>a[0]==='run').length,1);assert(!f.calls.some(a=>a[0]==='kill'));
});

for(const state of ['working','blocked','done'])test(`existing same-role worker is reused and queues safely while ${state}`,t=>{
 const f=fixture(t),made=executeRequest(f.c,f.req);f.terminals.get('tworker').status.state='done';captureReply(event('codex','initial done','initial'),{...f.c,terminal:'tworker'},'Codex');f.terminals.get('tworker').status.state=state;
 const req={id:randomUUID(),sender:'towner',action:'run',args:{agentId:made.agentId,name:'another-task',task:'Reuse the same role for a new task',acceptance:'Return the new verified result'}};const reused=executeRequest(f.c,req);assert(reused.reused);assert.equal(reused.created,false);assert.equal(roster(f.c).length,1);if(state!=='done'){assert.equal(drainDirect(f.c).reason,'agent_not_ready');assert.equal(f.calls.filter(x=>x[0]==='send').length,0);}f.terminals.get('tworker').status.state='done';assert.equal(drainDirect(f.c).terminal,'tworker');assert.equal(f.calls.filter(x=>x[0]==='run').length,1);assert.equal(executeRequest(f.c,req).collaborationId,reused.collaborationId);
});
test('new roles require complete expertise and a review of the actual existing roster',t=>{
 const f=fixture(t);delete f.req.args.profile;assert.throws(()=>executeRequest(f.c,f.req),/profile/);assert.equal(roster(f.c).length,0);assert(!f.calls.some(x=>x[0]==='run'));
});
test('a storage move retains the existing private project identity and memory location',t=>{
 const f=fixture(t),target=path.join(f.root,'cloud-project');fs.mkdirSync(target);const next=context(target,null,f.run,f.c.chat,{...f.config,projectOrigins:{[target]:f.root}});assert.equal(next.teamBase,f.c.teamBase);assert.equal(next.memoryDir,f.c.memoryDir);assert.equal(next.usageDir,f.c.usageDir);assert.notEqual(next.cwd,f.c.cwd);assert.equal(next.privateState,true);
});
test('cross-chat legacy delegation returns to its source and never creates a second process',async t=>{
 const f=fixture(t),made=executeRequest(f.c,f.req);f.terminals.get('tworker').status.state='done';captureReply(event('codex','initial done','initial'),{...f.c,terminal:'tworker'},'Codex');
 f.terminals.set('towner',{address:'towner',cwd:f.root,parent:null,state:'live',status:{app:'claude-code',state:'done'},labels:{}});const old=context(f.root,null,f.run,'original-chat',f.config);fs.mkdirSync(old.teamDir,{recursive:true});fs.copyFileSync(path.join(f.c.teamDir,'control.json'),path.join(old.teamDir,'control.json'));
 for(const name of ['direct-bindings.json','worker-bindings.json']){const file=path.join(f.c.teamDir,name),all=read(file),value=all.tworker;value.chat='original-chat';fs.writeFileSync(path.join(old.teamDir,name),JSON.stringify({tworker:value}));fs.writeFileSync(file,'{}');}f.terminals.get('tworker').labels['team.chat']='original-chat';
 const req={id:randomUUID(),sender:'towner',action:'run',args:{agentId:made.agentId,name:'same-role-next',task:'Same role new task',acceptance:'Return a verified answer'}};const queued=executeRequest(f.c,req);assert(queued.reused);assert.equal(drainDirect(f.c).sent,0);assert.equal(drainDirect(old).terminal,'tworker');captureReply(event('codex','verified next answer','next'),{...old,terminal:'tworker'},'Codex');const file=path.join(f.c.teamDir,'collaborations.json');assert.equal(read(file)[queued.collaborationId].status,'awaiting_review');const {drainCollaboration,collaborate}=await import('./direct.mjs');assert.equal(drainCollaboration(f.c).sent,1);const job=read(file)[queued.collaborationId];collaborate({...f.c,terminal:'towner'},{action:'accept',id:job.id,revision:job.revision,verification:'Verified the actual worker reply and read evidence',evidence:[]});assert.equal(read(file)[job.id].status,'done');assert.equal(executeRequest(f.c,req).status,'done');assert.equal(Object.keys(read(file)).length,1);assert.equal(f.calls.filter(x=>x[0]==='run').length,1);assert.equal(roster(f.c).length,1);assert.equal(read(path.join(old.teamDir,'direct-bindings.json')).tworker.activeJob,undefined);
});

function duplicateBindings(t,provider='codex'){
 const f=fixture(t,provider),made=executeRequest(f.c,f.req);f.terminals.get('tworker').status.state='done';captureReply(event(provider,'Initial completed','old-turn'),{...f.c,terminal:'tworker'},provider);
 const file=path.join(f.c.teamDir,'direct-bindings.json'),workerFile=path.join(f.c.teamDir,'worker-bindings.json');
 const bindings=read(file),workers=read(workerFile);bindings.tworker.legacyOwner='toldowner';bindings.tworker.ownerAwaitingReply=false;workers.tworker.owner='toldowner';
 const old=f.terminals.get('tworker');old.parent='toldowner';old.labels['team.owner']='toldowner';f.terminals.set('toldowner',{address:'toldowner',pid:9000,cwd:f.root,parent:null,state:'live',turn:1,status:{app:'claude-code',state:'done'},labels:{}});
 f.terminals.set('tmodern',{address:'tmodern',pid:5678,cwd:f.root,parent:null,state:'live',turn:2,status:{app:provider==='claude'?'claude-code':provider==='minimax'?'mcode':provider,state:'done'},labels:{'team.direct':'true','team.agent':made.agentId,'team.chat':'chat'}});
 bindings.tmodern={agentId:made.agentId,provider,chat:'chat',awaitingReply:false,delivered:true,lastMessageId:randomUUID()};fs.writeFileSync(file,JSON.stringify(bindings));fs.writeFileSync(workerFile,JSON.stringify(workers));
 const request={id:randomUUID(),sender:'towner',action:'run',args:{agentId:made.agentId,task:'Check new arithmetic',acceptance:'Return an independently checked result'}};
 return{...f,made,file,workerFile,request,before:fs.readFileSync(file),messageBytes:fs.readFileSync(path.join(f.c.teamDir,'messages.jsonl')),rosterBytes:fs.readFileSync(path.join(f.c.teamBase,'roster.json'))};
}
for(const provider of ['claude','codex','minimax','antigravity'])test(`${provider} duplicate idle legacy binding is backed up and retired without replacing the existing role or process`,t=>{
 const f=duplicateBindings(t,provider),result=executeRequest(f.c,f.request);assert(result.reused&&!result.created);assert.equal(result.bindingRepair.keptTerminal,'tmodern');assert.equal(result.bindingRepair.retiredCount,1);
 const b=read(f.file);assert(b.tworker.retired);assert.equal(b.tworker.supersededBy,'tmodern');assert.deepEqual(b.tmodern,JSON.parse(f.before).tmodern);assert(fs.readFileSync(path.join(f.c.teamBase,'roster.json')).equals(f.rosterBytes));assert(fs.readFileSync(path.join(f.c.teamDir,'messages.jsonl')).subarray(0,f.messageBytes.length).equals(f.messageBytes));
 const folder=path.join(f.c.teamBase,'binding-repairs',fs.readdirSync(path.join(f.c.teamBase,'binding-repairs'))[0]),backup=read(path.join(folder,'before.json'));assert.equal(backup.files.find(x=>x.file===f.file).content,f.before.toString());assert.equal(read(path.join(folder,'repair.json')).state,'complete');assert.equal(fs.statSync(path.join(folder,'before.json')).mode&0o777,0o600);
 assert.equal(drainDirect(f.c).terminal,'tmodern');assert.equal(f.terminals.get('tmodern').pid,5678);assert.equal(executeRequest(f.c,f.request).collaborationId,result.collaborationId);assert.equal(fs.readdirSync(path.join(f.c.teamBase,'binding-repairs')).length,1);assert.equal(f.calls.filter(x=>x[0]==='run').length,1);assert(!f.calls.some(x=>x[0]==='kill'||x[0]==='keys'||x[0]==='interrupt'));
});
for(const state of ['working','blocked','error'])test(`automatic binding repair preserves all bindings while the old worker is ${state}`,t=>{
 const f=duplicateBindings(t);f.terminals.get('tworker').status.state=state;assert.throws(()=>executeRequest(f.c,f.request),/修復暫緩/);assert(fs.readFileSync(f.file).equals(f.before));assert(!fs.existsSync(path.join(f.c.teamBase,'binding-repairs')));
});
for(const kind of ['pending-chat','pending-direct','pending-request','open-job','awaiting-reply','awaiting-owner','active-binding-job','unknown-reply','pending-registration','pending-skill','owner-working','unknown-pid','ambiguous-modern','foreign-label','malformed-json','symlink-file','symlink-chat','backup-failure'])test(`automatic binding repair fails closed for ${kind}`,t=>{
 const f=duplicateBindings(t),bindings=read(f.file);let reference=f.before;
 const write=(name,value)=>fs.writeFileSync(path.join(f.c.teamDir,name),JSON.stringify(value));
 if(kind.startsWith('pending-')&&['pending-chat','pending-direct','pending-request'].includes(kind)){const dir=path.join(f.c.teamDir,{'pending-chat':'chat-queue','pending-direct':'direct-queue','pending-request':'requests'}[kind]);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,randomUUID()+'.json'),'{}');}
 if(kind==='open-job')write('collaborations.json',{old:{id:'old',status:'awaiting_review'}});
 if(kind==='awaiting-reply')bindings.tworker.awaitingReply=true;
 if(kind==='awaiting-owner')bindings.tworker.ownerAwaitingReply=true;
 if(kind==='active-binding-job')bindings.tworker.activeJob='old';
 if(kind==='unknown-reply')delete bindings.tmodern.awaitingReply;
 if(kind==='pending-registration')write('agent-registrations.json',{pending:{status:'pending',agentId:f.made.agentId}});
 if(kind==='pending-skill')write('skill-requests.json',{pending:{status:'pending'}});
 if(kind==='owner-working')f.terminals.get('toldowner').status.state='working';
 if(kind==='unknown-pid')delete f.terminals.get('tworker').pid;
 if(kind==='ambiguous-modern'){delete bindings.tworker.legacyOwner;const old=f.terminals.get('tworker');old.parent=null;old.labels={'team.direct':'true','team.agent':f.made.agentId,'team.chat':'chat'};}
 if(kind==='foreign-label')f.terminals.get('tmodern').labels['team.agent']='foreign';
 fs.writeFileSync(f.file,JSON.stringify(bindings));reference=fs.readFileSync(f.file);
 if(kind==='malformed-json'){write('skill-requests.json','not-an-object');}
 if(kind==='symlink-file'){const copy=f.file+'.kept';fs.renameSync(f.file,copy);fs.symlinkSync(copy,f.file);}
 if(kind==='symlink-chat')fs.symlinkSync(f.c.teamDir,path.join(f.c.teamBase,'conversations','linked-chat'));
 if(kind==='backup-failure')fs.writeFileSync(path.join(f.c.teamBase,'binding-repairs'),'not a directory');
 assert.throws(()=>executeRequest(f.c,f.request));assert(fs.readFileSync(f.file).equals(reference));assert.equal(f.calls.filter(x=>x[0]==='run').length,1);assert(!f.calls.some(x=>['kill','keys','interrupt','send'].includes(x[0])));
});
test('binding repair detects a new queued task during inspection and leaves both sessions intact',t=>{
 const f=duplicateBindings(t),original=f.c.run;let reads=0;f.c.run=(cmd,args)=>{const result=original(cmd,args);if(args[0]==='get'&&args[1]==='tmodern'&&++reads===3){const dir=path.join(f.c.teamDir,'direct-queue');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,randomUUID()+'.json'),'{}');}return result;};assert.throws(()=>executeRequest(f.c,f.request),/修復暫緩/);assert(fs.readFileSync(f.file).equals(f.before));
});
test('binding repair rolls back retirement if the original process changes during commit',t=>{
 const f=duplicateBindings(t),original=f.c.run;f.c.run=(cmd,args)=>{const result=original(cmd,args);if(args[0]==='get'&&read(f.file).tworker.retired&&args[1]==='tmodern'){result.pid=9999;}return result;};assert.throws(()=>executeRequest(f.c,f.request),/保存後/);assert.deepEqual(read(f.file),JSON.parse(f.before));const dir=path.join(f.c.teamBase,'binding-repairs');assert.equal(read(path.join(dir,fs.readdirSync(dir)[0],'repair.json')).state,'aborted');
});
for(const kind of ['retired-working','retired-awaiting-reply','unadopted-working','unconfirmed-delivery'])test(`automatic binding repair protects ${kind} work`,t=>{
 const f=duplicateBindings(t),bindings=read(f.file);
 if(kind==='unconfirmed-delivery')bindings.tmodern.delivered=false;
 else{
  f.terminals.set('tbusy',{address:'tbusy',pid:9001,cwd:f.root,parent:'toldowner',state:'live',status:{app:'codex',state:'working'},labels:{}});
  if(kind.startsWith('retired-'))bindings.tbusy={agentId:f.made.agentId,retired:true,...(kind==='retired-awaiting-reply'?{awaitingReply:true}:{})};
  else{const workers=read(f.workerFile);workers.tbusy={owner:'toldowner',chat:'chat'};fs.writeFileSync(f.workerFile,JSON.stringify(workers));}
 }
 fs.writeFileSync(f.file,JSON.stringify(bindings));const before=fs.readFileSync(f.file);assert.throws(()=>executeRequest(f.c,f.request),/修復暫緩/);assert(fs.readFileSync(f.file).equals(before));
});
test('automatic repair preserves old-chat history and retires only the idle legacy binding across conversations',t=>{
 const f=duplicateBindings(t),old=context(f.root,null,f.run,'old-chat',f.config);fs.mkdirSync(old.teamDir,{recursive:true});const bindings=read(f.file),workers=read(f.workerFile),b=bindings.tworker,w=workers.tworker;
 b.chat='old-chat';w.chat='old-chat';delete bindings.tworker;delete workers.tworker;fs.writeFileSync(f.file,JSON.stringify(bindings));fs.writeFileSync(f.workerFile,JSON.stringify(workers));fs.writeFileSync(path.join(old.teamDir,'direct-bindings.json'),JSON.stringify({tworker:b}));fs.writeFileSync(path.join(old.teamDir,'worker-bindings.json'),JSON.stringify({tworker:w}));f.terminals.get('tworker').labels['team.chat']='old-chat';fs.writeFileSync(path.join(old.teamDir,'messages.jsonl'),'old history retained\n');const before=fs.readFileSync(path.join(old.teamDir,'messages.jsonl'));
 const result=executeRequest(f.c,f.request);assert(result.bindingRepair);assert(read(path.join(old.teamDir,'direct-bindings.json')).tworker.retired);assert(!read(f.file).tmodern.retired);assert(fs.readFileSync(path.join(old.teamDir,'messages.jsonl')).equals(before));assert.equal(drainDirect(f.c).terminal,'tmodern');
});
